#include<stdio.h>

int main(){
	int a[100], n, i, *p, s=0;
	printf("nhap so phan tu cho mang: ");
	scanf("%d", &n);
	for(i=0;i<n;i++){
		printf("nhap a[%d]= ",i);
		scanf("%d", &a[i]);
	}
	p=a;
	for(i=0;i<n;i++)
		s = s + *(p+i);
	printf("\n\ttong= %d",s);
}
