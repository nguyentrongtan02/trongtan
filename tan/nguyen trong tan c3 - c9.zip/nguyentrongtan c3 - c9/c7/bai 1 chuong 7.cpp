#include<stdio.h>

int main(){
	int a=10, b=20;
	int *cta, *ctb;
	cta=&a;
	ctb=&b;
	printf("tong 2 con tro la: %d",*cta+*ctb);
}
