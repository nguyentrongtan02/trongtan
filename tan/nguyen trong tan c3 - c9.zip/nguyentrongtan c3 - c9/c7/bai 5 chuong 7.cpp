#include<stdio.h> 
#include<conio.h>
int main(){ 
	int a[100], n, i, *p;
	printf("nhap so phan tu cho mang: ");
	scanf("%d", &n);
	for(i=0;i<n;i++){
		printf("nhap a[%d]= ",i);
		scanf("%d",&a[i]);
	}
	printf("\nmang sau khi in nguoc lai la: ");
	p=a;
	for(i=0;i<n;i++)
		printf("%5d", *(p+(n-1-i)));
	
 	return(0);
 }

