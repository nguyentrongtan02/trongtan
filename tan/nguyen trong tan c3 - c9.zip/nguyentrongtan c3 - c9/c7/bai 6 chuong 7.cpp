#include<stdio.h>

int main(){
	float pay;
	float *ptr_pay;
	pay=2313.54;
	ptr_pay = &pay;
	printf("pay=%f ", pay);
	printf("\n\n*ptr_pay=%f ",*ptr_pay);
	
	printf("\n\n&pay=%f ",&pay);
}
