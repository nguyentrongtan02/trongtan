#include<stdio.h>
#include<math.h>
int main()
{
	int n,i,j,souoc=0,s=0;
	do
	{
		printf("Nhap n:");scanf("%d",&n);
	}
	while(n<=0||n>=50);
	for(i=2;i<n;i++)
	{
		for(j=1;j<=i;j++)
		{
		if(i%j==0)
		souoc++;
		}
		if(souoc==2)
		s=s+i;
	}
	printf("Tong cua cac SNT nho hon %d la: %d",n,s);
return 0;
}
