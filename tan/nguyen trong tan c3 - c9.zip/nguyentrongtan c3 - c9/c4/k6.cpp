#include<stdio.h>
int main()
{
for(int i = 10; i < 99 ;++i)
            {
            int chuso, temp = i; // khai b�o bi?n

            chuso = temp/10; // l?y s? d?u ti�n

            temp %= 10;      // l?y s? th? hai


            int tong = chuso + temp;

            int tich = chuso * temp;

            if(tich == 2*tong)
            {
	        printf("so can tim la: %d\n", i);
            }

            }

            return 0;
}
