#include<stdio.h>
int chiahet(int m, int a, int b);
int main()
{
    int a, b, n, s=0;
    printf("nhap 3 so nguyen a b n voi a,b<n\n");
    scanf("%d%d%d", &a, &b, &n);
    if(a<n && b<n)
    {

       for (int i=1; i<n; i++)
        {
            if(chiahet(n, a, b) == 1)
            s+=i;
         }
    }
    printf("tong cac so nguyen < n chia het cho a nhung khong chia het cho b la %d", s);
}
int chiahet(int m,int a, int b)
{

    if (m%a==0 && m%b!=0)
        return 1;
    return 0;
}

