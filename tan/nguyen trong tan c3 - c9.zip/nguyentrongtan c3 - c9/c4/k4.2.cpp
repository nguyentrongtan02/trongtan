#include <stdio.h>
 
int main()
{
    int n,i;
    float S = 0;
    do
    {
        printf("\nNhap n : ");
        scanf("%d",&n);
    }
    while (n <= 0);
 
    for(i = 1;i <= n;i++)
    {
        S +=1/(float)i;
    }
    printf("\nS = %f", S);
return 0;
}
