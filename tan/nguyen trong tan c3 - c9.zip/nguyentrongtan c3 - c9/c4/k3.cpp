#include<stdio.h>

int main()

{

    int n,sodoi=0;

    printf("enter a number :");

    scanf("%d",&n);

    sodoi =n%10;

    int i = 0;

    int n1=n/10;

    while (n1>0)

    {

        i = n1 %10;

        sodoi = sodoi * 10 +i;

        n1 = n1/10;

    }

    

 

    if(sodoi == n)

    {

        printf("so doi xung ");

    }

    else

    {

        printf("khong doi xung");

    }

    

    return 0;

}
