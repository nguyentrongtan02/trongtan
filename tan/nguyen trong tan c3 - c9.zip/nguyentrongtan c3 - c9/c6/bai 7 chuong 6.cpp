#include<stdio.h>
void nhapmang(int a[], int &n){
	printf("nhap so phan tu cua mang: ");
	scanf("%d", &n);
	for(int i=0;i<n;i++){
		printf("nhap a[%d]= ", i);
		scanf("%d", &a[i]);
	}
}
void xuatmang(int a[], int n){
	for(int i=0;i<n;i++)
		printf("%2d", a[i]);
}
void maxmin(int a[], int n){
	int max=a[0], min=a[0];
	for(int i=0;i<n;i++){
		if(a[i]>max)
		max=a[i];
		if(a[i]<min)
		min=a[i];
	}
	printf("\ngia tri nho nhat la: %d\ngia tri lon nhat la: %d",min,max);
}
void demk(int a[], int n){
	int k, dem=0;
	printf("\nnhap k: ");
	scanf("%d", &k);
	for(int i=0;i<n;i++)
		if(a[i]==k)
		dem++;
	printf("\nmang co %d phan tu %d", dem, k);
}
void tinhtongtbc(int a[], int n){
	int tong=0;
	float tbc=0;
	for(int i=0;i<n;i++)
		tong+=a[i];
	tbc = tong/(n-1);
	printf("\ntong cac phan tu trong mang la: %d", tong);
	printf("\ntrug binh cong cac phan tu trong mang la: %.2f",tbc);
}
int main(){
	int a[100], n, x;
	nhapmang(a,n);
	printf("cac phan tu trong mang la: ");
	xuatmang(a,n);
	maxmin(a,n);
	demk(a,n);
	tinhtongtbc(a,n);
	return 0;
}
