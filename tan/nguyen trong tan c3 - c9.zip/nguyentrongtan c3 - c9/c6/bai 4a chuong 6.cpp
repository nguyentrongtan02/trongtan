#include<stdio.h>
void nhapmang(int a[], int &n){
	printf("nhap so phan tu trong mang: ");
	scanf("%d", &n);
	for(int i=0;i<n;i++){
		printf("nhap a[%d]= ",i);
		scanf("%d", &a[i]);
	}
}
void timx(int a[], int n){
	int vt, x, i;
	printf("\nnhap x can tim: ");
	scanf("%d", &x);
	for(i=0;i<n;i++)
		if(a[i]==x)
		vt=i;
	printf("\nvi tri cuoi cung cua %d trong mang la: %d",x,vt);
}
int main(){
	int a[100], n;
	nhapmang(a,n);
	timx(a,n);
}
