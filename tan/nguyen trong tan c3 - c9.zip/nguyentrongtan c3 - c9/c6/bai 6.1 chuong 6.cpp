#include<stdio.h>
void nhapmang(int a[], int &n){
	printf("nhap so phan tu cua mang: ");
	scanf("%d", &n);
	for(int i=0;i<n;i++){
		printf("nhap a[%d]= ", i);
		scanf("%d", &a[i]);
	}
}
void xuatmang(int a[], int n){
	for(int i=0;i<n;i++)
		printf("%2d", a[i]);
}
int kiemtrasnt(int n){
	if(n<2)
	return 0;
	for(int i=2;i<n;i++)
		if(n%i==0)
		return 0;
}
void suasnt(int a[], int n){
	for(int i=0;i<n;i++)
		if(kiemtrasnt(a[i]))
			a[i]=0;
	printf("\ncac snt sau khi sua thanh so 0 trong mang la: ");
	xuatmang(a,n);
}
int main(){
	int a[100], n;
	nhapmang(a,n);
	printf("cac phan tu trong mang la: ");
	xuatmang(a,n);
	suasnt(a,n);
	return 0;
}
