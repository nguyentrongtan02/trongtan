#include<stdio.h>
void nhapmang(int a[], int &n){
	printf("nhap so phan tu cua mang: ");
	scanf("%d", &n);
	for(int i=0;i<n;i++){
		printf("nhap a[%d]= ", i);
		scanf("%d", &a[i]);
	}
}
void xuatmang(int a[], int n){
	for(int i=0;i<n;i++)
		printf("%2d", a[i]);
}
void chen(int a[], int &n, int vt){
	for(int i=n;i>vt;i--)
		a[i]=a[i-1];
	n++;
}
void hoanvi(int &a, int &b){
	int c;
	c = a;
	a = b;
	b = c;
}
void chenXvaomangtangdan(int a[], int n, int x){
	for(int i=0;i<n;i++){
		for(int j=i+1;j<n;j++)
			if(a[i]>a[j])
			hoanvi(a[i],a[j]);
	}
	for(int i=0;i<n;i++)
		if(x<=a[i]){
		chen(a,n,i);
		a[i]=x;
		break;
	}
	else if(x>a[n-1]){
	a[n]=x;
	n++;
	break;
	}
	printf("\nmang tang dan sau khi chen x la: ");
	xuatmang(a,n);
}
int main(){
	int a[100], n, x;
	nhapmang(a,n);
	printf("cac phan tu trong mang la: ");
	xuatmang(a,n);
	printf("\nnhap gia tri cho x: ");
	scanf("%d", &x);
	chenXvaomangtangdan(a,n,x);
	return 0;
}
