#include<stdio.h>
void nhapmang(int a[], int &n){
	printf("nhap so phan tu trong mang: ");
	scanf("%d", &n);
	for(int i=0;i<n;i++){
		printf("nhap a[%d]= ",i);
		scanf("%d", &a[i]);
	}
}
void timminduong(int a[], int n){
	int min, dem=0;
	for(int i=0;i<n;i++)
		if(a[i]>0){ 
		min=a[i];
		dem++;
	}
	for(int i=0;i<n;i++)
		if(a[i]<min&&a[i]>0)
			min=a[i];
		if(dem==0)
		printf("\nmang khong co so nguyen duong");
		else
		printf("\so nguyen duong nho nhat trong mang la: %d",min);
}
int main(){
	int a[100], n;
	nhapmang(a,n);
	timminduong(a,n);
}
