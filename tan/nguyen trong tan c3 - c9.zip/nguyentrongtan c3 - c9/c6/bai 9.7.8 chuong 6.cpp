#include<stdio.h>
void nhapmang(int a[], int &n){
	printf("nhap so phan tu cua mang: ");
	scanf("%d", &n);
	for(int i=0;i<n;i++){
		printf("nhap a[%d]= ", i);
		scanf("%d", &a[i]);
	}
}
void xuatmang(int a[], int n){
	for(int i=0;i<n;i++)
		printf("\t%d", a[i]);
}
void demptchiahetcho3(int a[], int n){
	int dem=0, i;
	for(i=0;i<n;i++)
		if(a[i]%3==0)
		dem++;
	printf("\nso phan tu chia het cho 3 la: %d", dem);
}
void suasochiahetcho3(int a[], int n){
	for(int i=0;i<n;i++)
		if(a[i]%3==0)
		a[i]=100;
	printf("\nmang sau khi sua cac so chia het cho 3 thanh 100 la: ");
	xuatmang(a,n);
}
int main(){
	int a[100], n;
	nhapmang(a,n);
	printf("cac phan tu trong mang la: ");
	xuatmang(a,n);
	suasochiahetcho3(a,n);
	return 0;
}
