#include<stdio.h>
void nhapmang(int a[], int &n){
	printf("nhap so phan tu trong mang: ");
	scanf("%d", &n);
	for(int i=0;i<n;i++){
		printf("nhap a[%d]= ",i);
		scanf("%d", &a[i]);
	}
}
void inmang(int a[], int n){
	for(int i=0;i<n;i++)
		printf("%3d", a[i]);
}
void tachmang(int a[], int n, int b[], int &m, int c[], int &k){
	m=0;
	k=0;
	for(int i=0;i<n;i++){
		if(a[i]<0){
		b[m]=a[i];
		m++;
	}
		else{
		c[k]=a[i];
		k++;
		}
	}
}
int main(){
	int a[100], n, b[100], m, c[100], k;
	nhapmang(a,n);
	printf("\ncac phan tu cua mang a la: ");
	inmang(a,n);
	tachmang(a,n,b,m,c,k);
	printf("\ncac phan tu nguyen am b: ");
	inmang(b,m);
	printf("\ncac phan tu nguyen duong c: ");
	inmang(c,k);
}
