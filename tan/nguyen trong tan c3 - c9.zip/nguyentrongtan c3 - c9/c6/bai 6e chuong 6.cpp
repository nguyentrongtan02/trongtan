#include<stdio.h>
void nhapmang(int a[], int &n){
	printf("nhap so phan tu cua mang: ");
	scanf("%d", &n);
	for(int i=0;i<n;i++){
		printf("nhap a[%d]= ", i);
		scanf("%d", &a[i]);
	}
}
void xuatmang(int a[], int n){
	for(int i=0;i<n;i++)
		printf("%2d", a[i]);
}
void chen(int a[], int &n, int vt){
	for(int i=n;i>vt;i--)
		a[i]=a[i-1];
	n++;
}
int kiemtrasnt(int n){
	if(n<2)
	return 0;
	for(int i=2;i<n;i++)
		if(n%i==0)
		return 0;
}
void chen0trcSnt(int a[], int n){
	for(int i=0;i<n;i++)
		if(kiemtrasnt(a[i])){
		chen(a,n,i);
		a[i]=0;
		i++;
	}
	printf("\nmang sau khi chen cac so 0 trc cac snt la: ");
	xuatmang(a,n);
}
int main(){
	int a[100], n;
	nhapmang(a,n);
	printf("cac phan tu trong mang la: ");
	xuatmang(a,n);
	chen0trcSnt(a,n);
	return 0;
}
