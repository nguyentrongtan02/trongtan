#include<stdio.h>
#include<stdlib.h>
#include<time.h>
void nhapmang(int a[], int &n){
	srand((int)time(0));
	printf("nhap so phan tu cho mang: ");
	scanf("%d", &n);
	for(int i=0;i<n;i++)
		a[i]=1+rand()%100;
}
void inmang(int a[], int n){
	for(int i=0;i<n;i++)
		printf("%5d", a[i]);
}
void chen(int a[], int &n, int vt){
	for(int i=n;i>vt;i--)
		a[i]=a[i-1];
	n++;
}
void hoanvi(int &a, int &b){
	int c;
	c = a;
	a = b;
	b = c;
}
void chenXvaomangtangdan(int a[], int n){
	int x;
	printf("\nnhap x: ");
	scanf("%d", &x);
	for(int i=0;i<n;i++){
		for(int j=i+1;j<n;j++)
			if(a[i]>a[j])
			hoanvi(a[i],a[j]);
	}
	for(int i=0;i<n;i++)
		if(x<=a[i]){
		chen(a,n,i);
		a[i]=x;
		break;
	}
	else if(x>a[n-1]){
	a[n]=x;
	n++;
	break;
	}
	printf("\nmang tang dan sau khi chen x la: ");
	inmang(a,n);
}
int main(){
	int a[100], n;
	nhapmang(a,n);
	printf("cac phan tu cua mang a la: ");
	inmang(a,n);
	chenXvaomangtangdan(a,n);
}
