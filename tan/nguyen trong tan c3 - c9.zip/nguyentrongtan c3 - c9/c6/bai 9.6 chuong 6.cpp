#include<stdio.h>
void nhapmang(int a[], int &n){
	printf("nhap so phan tu trong mang: ");
	scanf("%d", &n);
	for(int i=0;i<n;i++){
		printf("nhap a[%d]= ",i);
		scanf("%d", &a[i]);
	}
}
void inmang(int a[], int n){
	for(int i=0;i<n;i++)
		printf("%3d", a[i]);
}
void xoa(int a[], int &n, int vt){
	for(int i=vt;i<n;i++)
		a[i]=a[i+1];
	n--;
}
void xoaptgionga(int a[], int n){
	int A, i;
	printf("\nnhap A: ");
	scanf("%d", &A);
	for(i=0;i<n;i++)
		if(a[i]==A){
		xoa(a,n,i);
		i--;
	}
	printf("\nmang sau khi xoa cac phan tu giong A la: ");
	inmang(a,n);
}
int main(){
	int a[100], n;
	nhapmang(a,n);
	printf("\ncac phan tu cua mang a la: ");
	inmang(a,n);
	xoaptgionga(a,n);
	
}
