#include<stdio.h>
#include<stdlib.h>
#include<time.h>
void nhapmang(int a[], int &n){
	srand((int)time(0));
	printf("nhap so phan tu cho mang: ");
	scanf("%d", &n);
	for(int i=0;i<n;i++)
		a[i]=50-rand()%100;
}
void inmang(int a[], int n){
	for(int i=0;i<n;i++)
		printf("%5d", a[i]);
}
void tachmang(int a[], int n, int b[], int &m, int c[], int &k){
	m=0;
	k=0;
	for(int i=0;i<n;i++){
		if(a[i]>0){
		b[m]=a[i];
		m++;
	}
		else{
		c[k]=a[i];
		k++;
		}
	}
}
int main(){
	int a[100], n, b[100], m, c[100], k;
	nhapmang(a,n);
	printf("\n\ncac phan tu cua mang a la:");
	inmang(a,n);
	tachmang(a,n,b,m,c,k);
	printf("\n\ncac phan tu nguyen duong mang b:");
	inmang(b,m);
	printf("\n\ncac phan tu nguyen am c:");
	inmang(c,k);
}
