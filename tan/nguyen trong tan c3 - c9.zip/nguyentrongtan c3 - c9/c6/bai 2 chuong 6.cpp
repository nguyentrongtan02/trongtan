#include<stdio.h>
void NhapMang(int a[], int &n){
	printf("nhap so phan tu: ");
	scanf("%d", &n);
	for(int i=0;i<n;i++){
		printf("[%d]= ",i);
		scanf("\t%d", &a[i]);
	}
}
void XuatMang(int a[], int n){
	for(int i=0;i<n;i++)
		printf("\t%5d", a[i]);
}
void KiemTraMangChan(int a[], int n){
	int dem = 0;
	for(int i=0;i<n;i++){
		if(a[i]%2==0)
		dem++;
	}
	if(dem==n)
	printf("\n\nmang toan chan");
	else
	printf("\n\nmang khong toan chan");
}
int KiemTraSNT(int n){
	if(n<2)
	return 0;
	else
	for(int i=2;i<n;i++)
		if(n%i==0)
		return 0;
}
void KiemTraMangSNT(int a[], int n){
	int dem = 0;
	for(int i=0;i<n;i++)
		if(KiemTraSNT(a[i]))
		dem++;
	if(dem==n)
	printf("\n\nmang toan nguyen to");
	else
	printf("\n\nmang khong la mang toan nguyen to");
}
void KiemTraMangTangDan(int a[], int &n){
	int dem=0;
	for(int i=0;i<n-1;i++)
		if(a[i]<a[i+1])
		dem++;
	if(dem==(n-1))
	printf("\n\nmang tang dan");
	else
	printf("\n\nmang khong tang dan");
}
int main(){
	int a[100], n;
	NhapMang(a,n);
	XuatMang(a,n);
	KiemTraMangChan(a,n);
	KiemTraMangSNT(a,n);
	KiemTraMangTangDan(a,n);
}
