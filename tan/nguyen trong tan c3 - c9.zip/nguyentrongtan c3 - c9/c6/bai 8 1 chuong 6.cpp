#include<stdio.h>
#include<stdlib.h>
#include<time.h>
void nhapmang(int a[], int &n){
	srand((int)time(0));
	printf("nhap so phan tu cho mang: ");
	scanf("%d", &n);
	for(int i=0;i<n;i++)
		a[i]=1+rand()%100;
}
void inmang(int a[], int n){
	for(int i=0;i<n;i++)
		printf("%5d", a[i]);
}
int main(){
	int a[100], n;
	nhapmang(a,n);
	printf("cac phan tu cua mang a la: ");
	inmang(a,n);
}
