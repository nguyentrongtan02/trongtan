#include<stdio.h>
void nhapmang(int a[], int &n){
	printf("nhap so phan tu trong mang: ");
	scanf("%d", &n);
	for(int i=0;i<n;i++){
		printf("nhap a[%d]= ",i);
		scanf("%d", &a[i]);
	}
}
void inmang(int a[], int n){
	for(int i=0;i<n;i++)
		printf("%3d", a[i]);
}
int kiemtrasnt(int n){
	if(n<2)
	return 0;
	for(int i=2;i<n;i++)
		if(n%i==0)
		return 0;
}
void suasnt(int a[], int n){
	for(int i=0;i<n;i++)
		if(kiemtrasnt(a[i]))
			a[i]=0;
}
int main(){
	int a[100], n;
	nhapmang(a,n);
	printf("\ncac phan tu cua mang khi chua giam dan la: ");
	inmang(a,n);
	suasnt(a,n);
	printf("\ncac phan tu SNT cua mang  sau khi sua = 0 la: ");
	inmang(a,n);
	
}
