#include<stdio.h>
#include<string.h>
char chradd(char a, char b, int &carry)  // C?ng hai ch? s?
{
    int temp = val(a) + val(b) + carry;
    carry = temp/10;
    return chr(temp %10);
}
pchar stradd (const pchar a, const pchar b, const pchar c) // C?ng hai s? c� nhi?u ch? s?
{
    int i = 0, carry = 0;    //Ban d?u, nh? b?ng 0
    while(a[i] && b[i]) c[i++] = chradd(a[i],b[i],carry); // C?ng l?n lu?t t? d?u d?n cu?i
    if(a[i])                             // N?u x�u a d�i hon x�u b
        while (a[i]) c[i++] = chradd(a[i],zero,carry); // C?ng ti?p a[i] v?i 0
    else                            // N?u x�u b d�i hon
        while (b[i]) c[i++] = chradd(b[i],zero,carry); // C?ng ti?p b[i] v?i 0
    if (carry) c[i++] = chr(carry);            //N?u cu?i c�ng m� nh? kh�c 0
    c[i] = 0;                    // �?t null v�o cu?i
    return c;
}
