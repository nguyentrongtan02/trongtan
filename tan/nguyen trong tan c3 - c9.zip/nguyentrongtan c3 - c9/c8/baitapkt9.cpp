
#include <stdio.h>
#include <string.h> 
 
int main() 
{
    char s[50];
    printf("nhap ki tu: ");
    gets(s);
 
    int i, count = 0; 
    for (i = 0; i < strlen(s); i++ )
    {
        if(s[i] == ' ') 
        {
            count++;
        }
    }
 
    printf("so chu ng trong day: %d\n", count + 1 );
 
    return 0;
}
