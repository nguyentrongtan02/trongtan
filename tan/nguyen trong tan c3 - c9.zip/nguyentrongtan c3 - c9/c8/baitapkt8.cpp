#include<stdio.h>
#include<string.h>
char* chuhoa(char *a)
{
    char *p = strdup(a);
    int n = strlen(p);
    int i;
    for (i = 0; i < n; i++)
        {
            if (p[i]>96 && p[i] < 123)
                {
                    p[i] -= 32;
                }
        }
     return p;
}
char* chuthuong(char *a)
{
    char *p = strdup(a);
    int n = strlen(p);
    int i;
    for (i = 0; i < n; i++)
        {
            if (p[i]>64 && p[i] < 91)
                {
                    p[i] += 32;
                }
        }
    return p;
}
int main()
{
    char chuoi[100];
    printf("xin moi ban nhap chuoi : ");
    fflush(stdin);
    gets(chuoi);
    printf("chuoi ban dau : %s\n", chuoi);
    printf("chuoi duoc chuyen sang hoa : %s\n", chuhoa(chuoi));
    printf("chuoi duoc chuyen sang thuong : %s\n", chuthuong(chuoi));
    return 0;
}
