#include<stdio.h>
#include<iostream>
#include<conio.h>
#include<math.h>
using namespace std;
int main()
{
	int a,b;
	float S;
	cout<<"Nhap a:";cin>>a;
	cout<<"Nhap b:";cin>>b;
	S=(float)-b/a;
	if(a==0)
	{
		if(b==0)
			cout<<"\nPhuong trinh vo so nghiem.";
		else
			cout<<"\nPhuong trinh vo nghiem.";			
	}
	
	else
	{
		cout<<"\nPhuong trinh co nghiem S="<<S;			
	}
}
