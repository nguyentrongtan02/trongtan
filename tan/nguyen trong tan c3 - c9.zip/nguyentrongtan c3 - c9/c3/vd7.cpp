#include <conio.h>
#include <math.h>
#include <stdio.h>
int main ()
{
    float a;
    printf("Nhap so Km da di:    ");
    scanf("%f",&a);
    if(a<=1)
              printf("So tien phai tra la 15000d");
    else
       if(a<=5)
             printf("so tien phai tra la %0.2fd",a*13500);
      else
         if(5<a)
            printf("So tien phai tra la: %0.2fd",a*11000);
         else
            if(a>120)
            printf("So tien phai tra la:  %0.2fd",a*11000*0.9);      
  getch();
  }
