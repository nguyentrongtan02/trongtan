#include<stdio.h>
#include<math.h>
int main()
{
	int a=2021,b,hieu;
	printf("Nhap nam sinh cua ban: ");
	scanf("%d", &b);
	hieu=a-b;
	printf("So tuoi cua ban la: %d tuoi ",hieu);
	return 0;
}
