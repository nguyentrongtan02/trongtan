#include <conio.h>
#include <math.h>
#include <stdio.h>
int main ()
{
    int a,b,c,d,min;
    printf("Nhap 4 so nguyen bat ki:    ");
    scanf("%d%d%d%d",&a,&b,&c,&d);
    min=a;
    if(min>b)
            min=b;
    if(min>c)
            min=c;       
    if(min>d)
            min=d;
    printf("So nho nhat la:  %d", min);
    getch();
}
