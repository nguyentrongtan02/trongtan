#include <conio.h>
#include <math.h>
#include <stdio.h>
int main ()
{
	int bsx,a,b,c,d,e;
	printf("Nhap 4 so cuoi bien xe cua ban: ");
	scanf("%d",&bsx);
	d=bsx%10;
	bsx=bsx/10;c=bsx%10;
	bsx=bsx/10;b=bsx%10;
	bsx=bsx/10;a=bsx%10;
	e=(a+b+c+d)%10;
	printf("Bien so xe cua ban %d nuoc",e);
	getch();
}
