#include <conio.h>
#include <math.h>
#include <stdio.h>
int main ()
{
   char a;
   printf("Nhap mot chu bat ki:    ");
   scanf("%c",&a);
   if (a<66)
      printf("Ket qua %c",a+32);
   else
      printf("ket qua %c",a-32);
   getch();   
}
