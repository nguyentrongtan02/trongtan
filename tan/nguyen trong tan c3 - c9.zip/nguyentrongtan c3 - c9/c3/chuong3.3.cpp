#include <conio.h>
#include <math.h>
#include <stdio.h>
int main ()
{
	char tensp;
	float dongia,soluong,sotien,tienthue;
	printf("NHap ten san pham:");
	scanf("%s");
	printf("Nhap don gia: ");
	scanf("%f",&dongia);
	printf("Nhap so luong: ");
	scanf("%f",&soluong);
	sotien=dongia*soluong;
	tienthue=0.1*sotien;
	printf("So tien: %0.2f \n Thue Gia tri gia tang: %0.2f ",sotien,tienthue);
	getch();
}
