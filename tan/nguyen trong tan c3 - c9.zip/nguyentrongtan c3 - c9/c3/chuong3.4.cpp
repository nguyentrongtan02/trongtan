
#include <conio.h>
#include <math.h>
#include <stdio.h>
int main ()
{
	float dt,dl,dh,dtb;
	printf("Nhap diem Toan: ");
	scanf("%f",&dt);
	printf("\nNhap diem Ly: ");
	scanf("%f",&dl);
	printf("\nNhap diem Hoa: ");
	scanf("%f",&dh);
	dtb=(dt+dl+dh)/ 3;
	printf("\nDiem Trung Binh la: %0.2f",dtb);
	getch();
}
