#include<stdio.h>
int main()
{
	float a,b,x;
	printf("Nhap phuong trinh bac nhat: ax+b=0");
	printf("Nhap he so cua a, b:");
	scanf("%f%f", &a, &b);
	if(a!=0){
		x=-b/a;
		printf("Phuong trinh co nghiem la: x= %.2f",x);
	}else{
		printf("Phuong trinh vo nghiem");	
	}
	return 0;
	}

