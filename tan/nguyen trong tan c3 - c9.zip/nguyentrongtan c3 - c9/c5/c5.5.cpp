#include <stdio.h>
 
int main(){
    int a, b;
    printf("\nNhap a = "); scanf("%d", &a);
    printf("\nNhap b = "); scanf("%d", &b);
 
    printf("a = %d, b = %d", a, b);
    printf("\na = %d, b = %d", a, b);
}
