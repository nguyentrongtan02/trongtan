#include <conio.h>
#include <math.h>
#include <stdio.h>
int main ()
{
   float a,b;
   printf("Nhap he so a va b cua PT ax+b=0 : ");
   scanf("%f%f",&a,&b);
      if(a!=0)
         printf("PT co nghiem la:  %0.2f",-b/a);
      else
         if(b==0)
            printf("Pt co vo so nghiem");
         else
            printf("Pt vo Nghiem");
   getch();
}

