#include <conio.h>
#include <math.h>
#include <stdio.h>
int main ()
{
   float a,b,c,delta;
   printf("Nhap he so a, b, c cua PT ax^2+bx+c=0:  ");
   scanf("%f%f%f",&a,&b,&c);
      if(a==0)
         {   if(b==0)
               {
                  if(c==0)
                     printf("Pt vo so nghiem");
                  else
                     printf("Pt vo Nghiem");
               }
            else
               printf("Phuong trinh co nghiem la: %0.2f",-c/b);
         }      
      else
         {
         delta=b*b-4*a*c;
         if(delta==0)
            printf("Pt co nghiem kep %0.2f",-b/2*a);
         if(delta>0)
            printf("Pt co 2 nghiem phan biet x1=%0.2f, x2=%0.2f",(-b-sqrt(delta))/2*a,(-b+sqrt(delta))/2*a);
         if(delta<0)
            printf("PT vo nghiem");   
         }
   getch();
}
