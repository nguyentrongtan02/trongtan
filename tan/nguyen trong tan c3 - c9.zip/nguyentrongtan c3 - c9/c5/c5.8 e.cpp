#include<stdio.h>
int main()
{
		int n, i, j, gt, s;
		printf("Nhap n: ");
		scanf("%d", &n);
		s = 0;
		for (i = 1; i <= n; i++)
		{
			gt = 1;
				for (j = 2 ; j <= i; j++)
					gt = gt * j;
			s = s + gt;
		}
		printf("1! + 2! + ... + %d! = %d",n,s);		
}
