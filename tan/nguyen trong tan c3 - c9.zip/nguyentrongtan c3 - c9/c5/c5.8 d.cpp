#include<stdio.h>
int main()
{
	int n, i, s;
	printf("Nhap n: ");
	scanf("%d", &n);
	s = 1;
	for (i = 1; i <= n; i++)
		s = s * i;
	printf("1 * 2 * ... * %d = %d", n, s);
}

