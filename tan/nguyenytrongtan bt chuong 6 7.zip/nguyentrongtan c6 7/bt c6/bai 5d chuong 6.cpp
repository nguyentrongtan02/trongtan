#include<stdio.h>
void nhapmang(int a[], int &n){
	printf("nhap so phan tu trong mang: ");
	scanf("%d", &n);
	for(int i=0;i<n;i++){
		printf("nhap a[%d]= ",i);
		scanf("%d", &a[i]);
	}
}
void inmang(int a[], int n){
	for(int i=0;i<n;i++)
		printf("%3d", a[i]);
}
void hoanvi(int &a, int &b){
	int c;
	c = a;
	a = b;
	b = c;
}
void tachmang(int a[], int n){
	for(int i=0;i<n;i++){
		for(int j=i+1;j<n;j++){
			if(a[i]==0&&a[j]!=0||a[i]<0&&a[j]>0||a[i]>0&&a[j]>0&&a[i]<a[j]||a[i]<0&&a[j]<0&&a[i]>a[j])
			hoanvi(a[i],a[j]);
		}
}
}
int main(){
	int a[100], n;
	nhapmang(a,n);
	printf("\ncac phan tu cua mang khi chua giam dan la: ");
	inmang(a,n);
	tachmang(a,n);
	printf("\ncac phan tu cua mang  sau khi sap xep la: ");
	inmang(a,n);
	
}
