#include <conio.h>
#include <stdio.h>
main()
{
int i=10,j=20;
int *p,*q;
p=&i;
q=&j;
*q=*p+4;
p=&j;
printf("i=%d \t j=%d \t *p=%d \t *q=%d",i,j,*p,*q);
getch();
}

