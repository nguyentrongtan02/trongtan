#include<stdio.h>
void nhapmang(int a[], int &n){
	printf("nhap so phan tu trong mang: ");
	scanf("%d", &n);
	for(int i=0;i<n;i++){
		printf("nhap a[%d]= ",i);
		scanf("%d", &a[i]);
	}
}
int kiemtrasnt(int n){
	if(n<2)
	return 0;
	for(int i=2;i<n;i++)
		if(n%i==0)
		return 0;
}
void timsntdautien(int a[], int n){
	int i, dem=0;
	for(i=0;i<n;i++)
		if(kiemtrasnt(a[i])){
		printf("\nvi tri dau tien cua SNT dau tien trong mang la: a[%d]",i);
		dem++;
		break;
	}
	if(dem==0)
	printf("\nmang khong co SNT");
}
int main(){
	int a[100], n;
	nhapmang(a,n);
	timsntdautien(a,n);
}
