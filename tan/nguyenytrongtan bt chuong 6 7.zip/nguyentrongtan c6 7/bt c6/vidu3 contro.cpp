#include<stdio.h>
#include<conio.h>
main()
{
int *pointer, a[10],i;
for(i=0;i<10;i++)
{
	printf("a[%d]=",i); 
   scanf("%d",&a[i]);
}
pointer=&a[0]; 	// pointer=a
for(i=0;i<10;i++)
printf("a[%d]=\t%d con tro :%d\n",i,a[i], *(pointer+i));
getch();
}

