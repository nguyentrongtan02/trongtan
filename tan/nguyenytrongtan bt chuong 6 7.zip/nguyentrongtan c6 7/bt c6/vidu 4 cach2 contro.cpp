#include<stdio.h>
#include<conio.h>
#include<math.h>
main(){
	int n,i;
	float a[20],s,*p;
	printf("nhap n=");
	scanf("%d",&n);
	p=a;
	printf("\nnhap gia tri cho mang:\n");
	for(i=0; i<n;i++){
		printf("nhap a[%d]=",i);
	scanf("%f",&p[i]);
}	
	printf("\nmang vua nhap la:");
		for(i=0; i<n;i++){
			printf("%4.1f",p[i]);
	}
	s=0;
	for(i=0; i<n;i++){
		s=s+p[i];
	}
	printf("\ntong la s=%4.1f\n",s);
	getch();
}

