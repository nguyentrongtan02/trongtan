#include<stdio.h>
#include<stdlib.h>
#include<time.h>
void nhapmang(int a[], int &n){
	srand((int)time(0));
	printf("nhap so phan tu cho mang: ");
	scanf("%d", &n);
	for(int i=0;i<n;i++)
		a[i]=1+rand()%100;
}
void inmang(int a[], int n){
	for(int i=0;i<n;i++)
		printf("%5d", a[i]);
}
void xoa(int a[], int &n, int vt){
	for(int i=vt;i<n;i++)
		a[i]=a[i+1];
	n--;
}
void xoaphantu(int a[], int n){
	int ti;
	do{
		printf("\nnhap phan tu thu i: ");
		scanf("%d",&ti);
	}while(ti<0||ti>(n-1));
	xoa(a,n,ti);
	printf("\nmang sau khi xoa phan tu thu i la: ");
	inmang(a,n);
}
int main(){
	int a[100], n;
	nhapmang(a,n);
	printf("\ncac phan tu cua mang a la: ");
	inmang(a,n);
	xoaphantu(a,n);
}
