#include<stdio.h>
void nhapmang(int a[], int &n){
	printf("nhap so phan tu cua mang: ");
	scanf("%d", &n);
	for(int i=0;i<n;i++){
		printf("nhap a[%d]= ", i);
		scanf("%d", &a[i]);
	}
}
void xuatmang(int a[], int n){
	for(int i=0;i<n;i++)
		printf("%2d", a[i]);
}
void xoadaucuoi(int a[], int n){
	for(int i=0;i<n;i++)
		a[i]=a[i+1];
	n-=2;
	printf("\nmang sau khi xoa dau va cuoi la: ");
	xuatmang(a,n);
}
int main(){
	int a[100], n;
	nhapmang(a,n);
	printf("cac phan tu trong mang la: ");
	xuatmang(a,n);
	xoadaucuoi(a,n);
	return 0;
}
