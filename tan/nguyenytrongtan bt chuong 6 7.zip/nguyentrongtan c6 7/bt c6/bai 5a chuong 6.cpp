#include<stdio.h>
void nhapmang(int a[], int &n){
	printf("nhap so phan tu trong mang: ");
	scanf("%d", &n);
	for(int i=0;i<n;i++){
		printf("nhap a[%d]= ",i);
		scanf("%d", &a[i]);
	}
}
void inmang(int a[], int n){
	for(int i=0;i<n;i++)
		printf("%3d", a[i]);
}
int kiemtrasnt(int n){
	if(n<2)
	return 0;
	for(int i=2;i<n;i++)
		if(n%i==0)
		return 0;
}
void tachsnt(int a[], int n, int b[], int &m){
	int i;
	m=0;
	for(i=0;i<n;i++)
		if(kiemtrasnt(a[i])){
		b[m]=a[i];
		m++;
	}
}
int main(){
	int a[100], n, b[100], m;
	nhapmang(a,n);
	printf("\ncac phan tu cua mang a: ");
	inmang(a,n);
	tachsnt(a,n,b,m);
	printf("\ncac SNT sau khi tach tu mang a sang mang b la: ");
	inmang(b,m);
}
