#include<stdio.h>
void nhapmang(int a[], int &n){
	printf("nhap so phan tu cua mang: ");
	scanf("%d", &n);
	for(int i=0;i<n;i++){
		printf("nhap a[%d]= ", i);
		scanf("%d", &a[i]);
	}
}
void xuatmang(int a[], int n){
	for(int i=0;i<n;i++)
		printf("%2d", a[i]);
}
int kiemtrasnt(int n){
	if(n<2)
	return 0;
	for(int i=2;i<n;i++)
		if(n%i==0)
		return 0;
}
void hoanvi(int &a, int &b){
	int c;
	c = a;
	a = b;
	b = c;
}
void chen(int a[], int &n, int vt){
	for(int i=n;i>vt;i--)
		a[i]=a[i-1];
	n++;
}
void xoa(int a[], int &n, int vt){
	for(int i=vt;i<n-1;i++)
		a[i]=a[i+1];
	n--;
}
void suasnt(int a[], int n){
	for(int i=0;i<n;i++)
		if(kiemtrasnt(a[i]))
			a[i]=0;
	printf("\ncac snt sau khi sua thanh 0 trong mang la: ");
	xuatmang(a,n);
}

void chendaucuoi(int a[], int n, int x){
	for(int i=n;i>0;i--)
		a[i]=a[i-1];
	n=n+2;
	a[0]=x;
	a[n-1]=x;
	printf("\nmang sau khi chen x vao dau va cuoi la: ");
	xuatmang(a,n);
}
void chenXvaomangtangdan(int a[], int n, int x){
	for(int i=0;i<n;i++){
		for(int j=i+1;j<n;j++)
			if(a[i]>a[j])
			hoanvi(a[i],a[j]);
	}
	for(int i=0;i<n;i++){
		if(x<a[i]){
		chen(a,n,i);
		a[i]=x;
		break;
	}
	}
	printf("\nmang tang dan sau khi chen la: ");
	xuatmang(a,n);
}
void chen0trcSnt(int a[], int n){
	for(int i=0;i<n;i++)
		if(kiemtrasnt(a[i])){
		chen(a,n,i-1);
		a[i-1]=0;
		i++;
	}
	printf("\nmang sau khi chen cac so 0 trc cac snt la: ");
	xuatmang(a,n);
}
void xoadaucuoi(int a[], int n){
	for(int i=0;i<n;i++)
		a[i]=a[i+1];
	n-=2;
	printf("\nmang sau khi xoa dau va cuoi la: ");
	xuatmang(a,n);
}
void xoasnt(int a[], int n){
	for(int i=0;i<n;i++){
		if(kiemtrasnt(a[i]))
		xoa(a,n,i);
		i--;
	}
	printf("\nmang sau khi xoa snt la: ");
	xuatmang(a,n);
}
int main(){
	int a[100], n, x;
	nhapmang(a,n);
	printf("cac phan tu trong mang la: ");
	xuatmang(a,n);
	printf("\nnhap gia tri cho x: ");
	scanf("%d", &x);
	chendaucuoi(a,n,x);
	chenXvaomangtangdan(a,n,x);
	chen0trcSnt(a,n);
	xoadaucuoi(a,n);
	xoasnt(a,n);
	return 0;
}


