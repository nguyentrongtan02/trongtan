#include<stdio.h>
void nhapmang(int a[], int &n){
	printf("nhap so phan tu trong mang: ");
	scanf("%d", &n);
	for(int i=0;i<n;i++){
		printf("nhap a[%d]= ",i);
		scanf("%d", &a[i]);
	}
}
void timsnt(int a[], int n){
	int min=a[0];
	for(int i=1;i<n;i++)
		if(a[i]<min)
			min=a[i];
	printf("\nvi tri nho nhat trong mang la: %d",min);
}
int main(){
	int a[100], n;
	nhapmang(a,n);
	timsnt(a,n);
}
