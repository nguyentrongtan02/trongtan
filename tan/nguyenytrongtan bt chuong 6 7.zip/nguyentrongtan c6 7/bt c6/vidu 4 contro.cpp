#include<stdio.h>
#include<conio.h>
#include<math.h>
int main()
{ int n,i;
float a[20],s;
printf("nhap n=");
scanf("%d",&n);
printf("\nnhap gia tri cho mang:\n");
for (i=0; i<n;i++)
{ printf("nhap a[%d]=",i);
   scanf("%f",&a[i]);
}
printf("\nmang vua nhap la:");
for (i=0; i<n;i++)
{
printf("%4.1f",a[i]);
}
s=0;
for (i=0; i<n;i++)
{
s=s+a[i];
}
printf("\ntong la s=%4.1f\n",s);
getch();
}

