#include <conio.h>
#include <stdio.h>
void main(){
	int *pointer, n,i;
	printf("Mang co bao nhieu phan tu"); scanf("%d",&n);
	pointer= (int*) malloc(n*sizeof(int));
	for(i=0;i<n;i++){	
		printf("Phan tu thu %d : ",i+1); scanf("%d",&pointer[i]); }
	for(i=0;i<n;i++){ 
		printf("Phan tu thu %d = %d \t",i+1,pointer[i]); }
	free(pointer);
	getch();
}

