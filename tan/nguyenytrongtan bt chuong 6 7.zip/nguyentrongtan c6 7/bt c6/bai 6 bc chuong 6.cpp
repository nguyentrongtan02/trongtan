#include<stdio.h>
void nhapmang(int a[], int &n){
	printf("nhap so phan tu cua mang: ");
	scanf("%d", &n);
	for(int i=0;i<n;i++){
		printf("nhap a[%d]= ", i);
		scanf("%d", &a[i]);
	}
}
void xuatmang(int a[], int n){
	for(int i=0;i<n;i++)
		printf("%2d", a[i]);
}
void chendaucuoi(int a[], int n, int x){
	for(int i=n;i>0;i--)
		a[i]=a[i-1];
	n=n+2;
	a[0]=x;
	a[n-1]=x;
	printf("\nmang sau khi chen x vao dau va cuoi la: ");
	xuatmang(a,n);
}
int main(){
	int a[100], n, x;
	nhapmang(a,n);
	printf("cac phan tu trong mang la: ");
	xuatmang(a,n);
	printf("\nnhap gia tri cho x: ");
	scanf("%d", &x);
	chendaucuoi(a,n,x);
	return 0;
}
