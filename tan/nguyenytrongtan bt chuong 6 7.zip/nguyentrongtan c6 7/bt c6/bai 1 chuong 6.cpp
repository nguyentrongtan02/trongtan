#include<stdio.h>
void NhapMang(int a[], int &n){
	printf("nhap so phan tu: ");
	scanf("%d", &n);
	for(int i=0;i<n;i++){
		printf("[%d]= ",i);
		scanf("\t%d", &a[i]);
	}
}
void XuatMang(int a[], int n){
	for(int i=0;i<n;i++)
		printf("\t%5d", a[i]);
}
int main(){
	int a[100], n;
	NhapMang(a,n);
	XuatMang(a,n);
}
