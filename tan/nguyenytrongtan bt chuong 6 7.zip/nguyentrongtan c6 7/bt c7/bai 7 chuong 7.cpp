#include <stdio.h>
#include <conio.h>
int main()
{
	int *x, y = 2;
	x = &y;
	*x+=y++;
	printf("%d %d", *x, y);
	getch();
}

