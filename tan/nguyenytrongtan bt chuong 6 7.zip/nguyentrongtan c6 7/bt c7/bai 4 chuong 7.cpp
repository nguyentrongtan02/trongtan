#include<stdio.h>
#include<conio.h>
int string_ln(char*p){
 	int count = 0; 
	while (*p != '\0'){
		count++;
		p++; 
	}
	return count; 
}
int main(){
	char str[20];
	printf("\nNhap chuoi bat ky: "); 
	gets(str);
	printf("\nDo dai chuoi %s la: %d", str, string_ln(str));
	return(0); 
} 

